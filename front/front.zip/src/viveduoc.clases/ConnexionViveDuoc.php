<?php

class ConexionViveDuoc {
    private $server = "localhost:3306";
    private $username = "root";
    private $password = "";
	private $database = "vive_duoc;charset=utf8";

    public function connect(){
		try {
			$connect = new PDO('mysql:host='.$this->server.';dbname=' . $this->database, $this->username, $this->password);
			$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			return $connect;	
		} catch (Exception $e) {
			die('Error db(connect) '.$e->getMessage());
		}
	}


   
}